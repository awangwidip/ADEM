### `npm install`
Install necessary libary
### `npm start`
Start the project